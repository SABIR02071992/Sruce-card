package com.mpfaith.adminmp5.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.mpfaith.adminmp5.Adapter.ColorAdapter;
import com.mpfaith.adminmp5.Model.ProductStockModel;
import com.mpfaith.adminmp5.Model.UpdateListProductModel;
import com.mpfaith.adminmp5.R;
import com.mpfaith.adminmp5.api.APIClient;
import com.mpfaith.adminmp5.api.RestAPI;
import com.mpfaith.adminmp5.utils.NetConnection;
import com.mpfaith.adminmp5.utils.ProgressDialogScreen;
import com.mpfaith.adminmp5.utils.UserSharedPreferences;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import eu.amirs.JSON;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.content.ContentValues.TAG;

public class UpdateProductLisActivity extends AppCompatActivity {
    Toolbar toolbar;
    RestAPI api;
    ArrayList<String> meterSrArrayList;
    UserSharedPreferences userSharedPreferences;
    ArrayAdapter<String> meterSrNumAdapter;
    String str_brand;
    String str_category,str_category_id;
    EditText available_Quantity,product_brand,product_description,
            product_price,product_dist,color_edit,size_edit,product_Id,created_by;
    ImageView imageView,image_set;
    ListView listView;
    private static final int CAMERA_PIC_REQUEST = 1337;
    private static final int SELECT_IMAGE = 1338;
    private Bitmap bitmap;
    ArrayList<Uri> imagesUriArrayList ;
    ArrayList<String>api_array_list;
    ArrayList<String>imagesCammerArrayList;
    ArrayList<String>  cammer_api_array_list;
    private Uri fileURI;
    Button submit_button;
    ImageView color_add;
    ColorAdapter adapter;
    String str_image_aa;
    String str_product_name,str_available_Quantity,str_product_brand,
            str_product_dist,str_product_price,str_product_description,str_product_id,str_cgst,str_sgst,str_commission,str_quantity,str_createdBy,str_sellQuantity,str_totalPrice;
    ProductStockModel model;
    ArrayList<ProductStockModel> color_list;
    ArrayList<String> size_list;
    TextView product_name;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_product_lis);
        initView();
    }

    private void initView() {
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        assert getSupportActionBar() != null;
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(true);
        getSupportActionBar().setTitle("Update Product List");

        api = APIClient.getClient().create(RestAPI.class);
        userSharedPreferences = new UserSharedPreferences(this);


// get all field.......
        str_product_id=getIntent().getStringExtra("productId");
        str_product_name=getIntent().getStringExtra("productName");
        str_product_brand=getIntent().getStringExtra("productBrand");
        str_product_price=getIntent().getStringExtra("productPrice");
        str_product_dist=getIntent().getStringExtra("discount");
        str_product_description=getIntent().getStringExtra("productDescription");



        submit_button=findViewById(R.id.submit_button);
        color_add=findViewById(R.id.color_add);
        color_edit=findViewById(R.id.color_edit);
        size_edit=findViewById(R.id.size_edit);
        product_name=findViewById(R.id.product_name);
        available_Quantity=findViewById(R.id.available_Quantity);
        product_brand=findViewById(R.id.product_brand);
        product_price=findViewById(R.id.product_price);
        product_dist=findViewById(R.id.product_dist);
        product_description=findViewById(R.id.product_description);

//setText in all field......
        product_name.setText(str_product_name);
        product_brand.setText(str_product_brand);
        product_price.setText(str_product_price);
        product_dist.setText(str_product_dist);
        product_description.setText(str_product_description);



//        listView.setVisibility(View.INVISIBLE);
        api = APIClient.getClient().create(RestAPI.class);
        userSharedPreferences = new UserSharedPreferences(this);

        submit_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                str_product_name = product_name.getText().toString().trim();
                str_product_brand = product_brand.getText().toString().trim();
                str_product_dist = product_dist.getText().toString().trim();
                str_product_price = product_price.getText().toString().trim();
                str_product_description = product_description.getText().toString().trim();




                if (NetConnection.isNetworkAvailable(UpdateProductLisActivity.this)) {

                    getAddUpdateApi(str_available_Quantity,str_product_id,str_product_name,str_product_brand,str_product_dist,str_product_price,str_product_description);

                }else{
                    Toast.makeText(UpdateProductLisActivity.this, "No Internet Connection", Toast.LENGTH_SHORT).show();
                }

            }
        });



    }

    private void getAddUpdateApi(String str_available_Quantity,String str_product_id, String str_product_name, String str_product_brand, String str_product_dist, String str_product_price, String str_product_description) {

        Map<String,String>requestBody=new HashMap<>();
        requestBody.put("productId",str_product_id);
        requestBody.put("productName",str_product_name);
        requestBody.put("productBrand",str_product_brand);
        requestBody.put("productPrice",str_product_price);
        requestBody.put("discount",str_product_dist);
        requestBody.put("productDescription",str_product_description);
        requestBody.put("createdBy",userSharedPreferences.getLoginID());


        Map<String,Map>requestBody1=new HashMap<>();
        requestBody1.put("payload",requestBody);
        ProgressDialogScreen.showProgressDialog(UpdateProductLisActivity.this);
        Call<UpdateListProductModel>call=api.getUpdateProduct(requestBody1);
        call.enqueue(new Callback<UpdateListProductModel>() {
            @Override
            public void onResponse(Call<UpdateListProductModel> call, Response<UpdateListProductModel> response) {
                ProgressDialogScreen.hideProgressDialog();
                if(response.isSuccessful()){
                    UpdateListProductModel updateListProductModel=response.body();
                    if (updateListProductModel.getPayload().getRespCode()!=null){
                        if (updateListProductModel.getPayload().getRespCode().equals(200)){

                            Intent intent=new Intent(UpdateProductLisActivity.this, ProductListActivity.class);
                            startActivity(intent);
                            finish();

                        }else {
                            Toast.makeText(UpdateProductLisActivity.this, "null " + response.message(), Toast.LENGTH_LONG).show();

                        }

                    }else {
                        Toast.makeText(UpdateProductLisActivity.this, "ERROR : 101 " + response.message(), Toast.LENGTH_LONG).show();


                    }

                }

            }

            @Override
            public void onFailure(Call<UpdateListProductModel> call, Throwable t) {
                Toast.makeText(UpdateProductLisActivity.this, "server error" ,Toast.LENGTH_LONG).show();


            }
        });
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
            default:

                return super.onOptionsItemSelected(item);
        }
        return false;
    }
}