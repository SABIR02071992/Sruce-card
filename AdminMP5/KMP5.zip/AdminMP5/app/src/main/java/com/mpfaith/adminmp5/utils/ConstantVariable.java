package com.mpfaith.adminmp5.utils;

public class ConstantVariable {
   public static String BASE_URL="http://103.228.112.235:9090/ecommerce/";

//public static String BASE_URL="http://192.168.1.16:8080/ecommerce/";
    public static class UserSharedPref{
        public static final String LOGIN_ID = "user_id";
        public static final String FIRST_NAME= "first_name";
        public static final String LAST_NAME= "last_name";
        public static final String MEMBER_TYPE = "member_type";
        public static final String URL = "url";
        public static final String USER_FILE = "user_file";
        public static final String IS_LOGIN = "is_login";
        public static final String PROFILE = "Profile_image";
    }
}

