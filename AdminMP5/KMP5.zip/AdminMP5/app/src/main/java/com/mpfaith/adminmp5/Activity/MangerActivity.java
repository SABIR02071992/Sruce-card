package com.mpfaith.adminmp5.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.mpfaith.adminmp5.R;

public class MangerActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manger);
    }
}