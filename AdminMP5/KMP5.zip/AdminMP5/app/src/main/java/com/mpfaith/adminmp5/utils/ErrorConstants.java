package com.mpfaith.adminmp5.utils;



public class ErrorConstants {

   public  static String JSONDATA_NULL="json data null";

    public  static String RESPONSE_NULL="reponse null";

    public   static String Fail_message="Oops! Your network connection is slow or disconnected";

    public   static String NETWORK_GONE="Oops! Network is not available";
}
